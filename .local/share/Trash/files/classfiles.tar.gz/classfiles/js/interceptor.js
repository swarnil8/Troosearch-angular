var Interceptor = function() {

}

Interceptor.prototype = {
  constructor: Interceptor
}
