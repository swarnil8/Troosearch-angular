var Api = function() {
  this.sampleObj = {
    post: {
      id: 1,
      imageUrl: './images/1.jpg'
    },
    likes: [{
      id: 100,
      name: 'Manmohan',
      imageUrl: './images/1.jpg'
    }, {
      id: 101,
      name: 'Swarnil',
      imageUrl: './images/1.jpg'
    }, {
      id: 102,
      name: 'Mahima',
      imageUrl: './images/1.jpg'
    }, {
      id: 103,
      name: 'Kamal',
      imageUrl: './images/1.jpg'
    },{
      id: 104,
      name: 'Mohit',
      imageUrl: './images/1.jpg'
    },{
      id: 105,
      name: 'Kamal',
      imageUrl: './images/1.jpg'
    }]
  };

};

Api.prototype = {
  constructor: Api,
  getLikes: function( cb ) {
     cb( this.sampleObj );
  }
}
